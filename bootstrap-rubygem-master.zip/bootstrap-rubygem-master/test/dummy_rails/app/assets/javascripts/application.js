//= require jquery
//= require popper.js
//= require bootstrap-sprockets

jQuery(function ($) {
    $('[data-toggle="tooltip"]').tooltip()
});
