# frozen_string_literal: true

module Bootstrap
  VERSION       = '4.3.1'
  BOOTSTRAP_SHA = '8fa0d3010112dca5dd6dd501173415856001ba8b'
end
